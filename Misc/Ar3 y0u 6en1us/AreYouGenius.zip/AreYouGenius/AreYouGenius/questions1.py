from cryptography.fernet import Fernet
import json
import sys

# Function to decrypt flag1.json.enc and retrieve answers and flag
def get_answers_and_flag():
    try:
        # Load the encryption key
        with open(".flag_key.key", "rb") as key_file:
            key = key_file.read()

        # Initialize the cipher
        cipher = Fernet(key)

        # Read the encrypted data from flag1.json.enc
        with open("flag1.json.enc", "rb") as enc_file:
            encrypted_data = enc_file.read()

        # Decrypt the data
        decrypted_data = cipher.decrypt(encrypted_data)

        # Load the decrypted JSON data without printing it
        data = json.loads(decrypted_data.decode('utf-8'))

        # Return answers and flag
        return data['answers'], data['flag']
    
    except FileNotFoundError as e:
        print(f"File not found: {e}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"An error occurred: {e}")
        sys.exit(1)

def question_1(answers):
    print("Question 1: Convert 73 decimal to binary.")
    answer = input("Your answer: ")
    if answer == answers['question_1']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)  # Exit if the answer is incorrect.

def question_2(answers):
    print("Question 2: What is the mean of these numbers 1, 2, 3, 4, 4, 5, 6, 7, 8, 8, 9, 9?")
    answer = input("Your answer: ")
    if answer == answers['question_2']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)  # Exit if the answer is incorrect.

def question_3(answers):
    print("Question 3: Solve for 𝑥 in the equation 3x+5=20")
    answer = input("Your answer: ")
    if answer == answers['question_3']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)  # Exit if the answer is incorrect.

def question_4(answers):
    print("Question 4: In a right triangle, if one leg is 6 cm and the other leg is 8 cm, what is the length of the hypotenuse?")
    answer = input("Your answer: ")
    if answer == answers['question_4']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)  # Exit if the answer is incorrect.

def question_5(answers):
    print("Question 4: Convert 212°F to Kelvin")
    answer = input("Your answer: ")
    if answer == answers['question_5']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)  # Exit if the answer is incorrect.

def question_6(answers):
    print("Question 6: A car travels 60 miles in 1 hour. How long will it take to travel 150 miles at the same speed?")
    answer = input("Your answer: ")
    if answer == answers['question_6']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_7(answers):
    print("Question 7: Find the area of a circle with a radius of 10 cm.")
    answer = input("Your answer: ")
    if answer == answers['question_7']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_8(answers):
    print("Question 8: Find the area of a triangle with a base of 10 cm and a height of 6 cm.")
    answer = input("Your answer: ")
    if answer == answers['question_8']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_9(answers):
    print("Question 9: If a book costs P250 and is on sale for 10% off, what is the sale price?")
    answer = input("Your answer: ")
    if answer == answers['question_9']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_10(answers):
    print("Question 10: A factory produces 120 toys every hour. How many toys will it produce in 5 hours?")
    answer = input("Your answer: ")
    if answer == answers['question_10']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_11(answers):
    print("Question 11: Find the median of the set: 8, 3, 5, 7, 6.")
    answer = input("Your answer: ")
    if answer == answers['question_11']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_12(answers):
    print("Question 12: A recipe calls for 2 cups of flour to make 12 cookies. How many cups of flour are needed for 30 cookies?")
    answer = input("Your answer: ")
    if answer == answers['question_12']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_13(answers):
    print("Question 13: If you save P500 a month, how much will you have saved after 2 years?")
    answer = input("Your answer: ")
    if answer == answers['question_13']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_14(answers):
    print("Question 14: A train leaves the station at 60 miles per hour. How far will it travel in 4 hours?")
    answer = input("Your answer: ")
    if answer == answers['question_14']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_15(answers):
    print("Question 15: Find the volume of a rectangular prism with dimensions 4 cm, 3 cm, and 5 cm.")
    answer = input("Your answer: ")
    if answer == answers['question_15']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_16(answers):
    print("Question 16: In a right triangle, if the hypotenuse is 13 units and one leg is 5 units, find the other leg.")
    answer = input("Your answer: ")
    if answer == answers['question_16']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_17(answers):
    print("Question 17: Find the range of the data set: 4, 9, 2, 7, 10.")
    answer = input("Your answer: ")
    if answer == answers['question_17']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_18(answers):
    print("Question 18: A pencil costs P12 and a notebook costs P30. If you buy 4 pencils and 3 notebooks, what is the total cost?")
    answer = input("Your answer: ")
    if answer == answers['question_18']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_19(answers):
    print("Question 19: How many sides does a dodecagon have?")
    answer = input("Your answer: ")
    if answer == answers['question_19']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def question_20(answers):
    print("Question 20: What is cos(0)?")
    answer = input("Your answer: ")
    if answer == answers['question_20']:
        print("Correct!")
    else:
        print("Incorrect. Exiting the CTF.")
        sys.exit(1)

def statement_1(answers):
    print("Are you tired?")
    answer = input("yes or no: ")
    if answer == answers['statement_1']:
        print ("Correct!")
    else:
        print("You're a Genius! But I can't give you the flag. Exiting the CTF")
        sys.exit(1)

def main():
    print("Welcome to the H4G FINALS 2024! Do you know mathematics?")
    
    answers, flag = get_answers_and_flag()
    
    if answers and flag:
        question_1(answers)
        question_2(answers)
        question_3(answers)
        question_4(answers)
        question_5(answers)
        question_6(answers)
        question_7(answers)
        question_8(answers)
        question_9(answers)
        question_10(answers)
        question_11(answers)
        question_12(answers)
        question_13(answers)
        question_14(answers)
        question_15(answers)
        question_16(answers)
        question_17(answers)
        question_18(answers)
        question_19(answers)
        question_20(answers)
        statement_1(answers)
        print(f"Congratulations! Here is your flag: {flag}")
    else:
        print("Unable to retrieve answers or flag.")
        sys.exit(1)

if __name__ == "__main__":
    main()

